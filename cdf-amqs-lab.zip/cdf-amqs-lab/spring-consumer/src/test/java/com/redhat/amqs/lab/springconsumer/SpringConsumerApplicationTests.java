package com.redhat.amqs.lab.springconsumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringConsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}
