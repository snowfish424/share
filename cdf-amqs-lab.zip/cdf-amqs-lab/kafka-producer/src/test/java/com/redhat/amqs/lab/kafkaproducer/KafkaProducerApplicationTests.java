package com.redhat.amqs.lab.kafkaproducer;

import java.io.IOException;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.kafka.test.context.EmbeddedKafka;

@SpringBootTest
@EmbeddedKafka(count = 1,ports = {9091})
class KafkaProducerApplicationTests {

	@Test
	void contextLoads() throws IOException {
		System.in.read();
	}

}
