package dev.fullstackcode.kafka.consumer.listeners;

import dev.fullstackcode.kafka.consumer.dto.Employee;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;


//@Component
@Service
public class KafkaConsumer {

    @KafkaListener(groupId ="groups", topics = "${cloudkarafka.topic}" )
    public void listen(Employee data) {
        System.out.println(data);

    }
}
