# springboot-cloudkarafka-producer

https://fullstackcode.dev/2022/05/30/how-to-publish-subscribe-to-kafka-with-spring-boot-and-sasl-scram/
