package dev.fullstackcode.kafka.producer;

import java.io.IOException;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.kafka.test.context.EmbeddedKafka;

@SpringBootTest
@EmbeddedKafka(count = 1,ports = {9092})
class SpringbootKafkaProducerApplicationTests {

	@Test
	void contextLoads() throws IOException {
		System.in.read();
	}

}
