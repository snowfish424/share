package com.redhat.amqs.lab.springconsumer;

import java.io.IOException;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.kafka.test.context.EmbeddedKafka;

@SpringBootTest
@EmbeddedKafka(count = 1,ports = {9092})
class SpringConsumerApplicationTests {

	@Test
	void contextLoads() throws IOException {
		System.in.read();
	}

}
