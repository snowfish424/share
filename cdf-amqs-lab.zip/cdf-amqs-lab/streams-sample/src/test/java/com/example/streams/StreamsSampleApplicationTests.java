package com.example.streams;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StreamsSampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
