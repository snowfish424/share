package com.example.streams.core.account.service;

import org.springframework.stereotype.Service;

@Service
public class AccountService {

}
