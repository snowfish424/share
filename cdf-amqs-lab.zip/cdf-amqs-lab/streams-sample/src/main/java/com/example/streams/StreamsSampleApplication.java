package com.example.streams;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StreamsSampleApplication {

	public static void main(String[] args) throws InterruptedException {
		SpringApplication.run(StreamsSampleApplication.class, args);
	}

}
