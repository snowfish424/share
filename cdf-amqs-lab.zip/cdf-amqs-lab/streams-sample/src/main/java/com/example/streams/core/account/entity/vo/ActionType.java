package com.example.streams.core.account.entity.vo;

public enum ActionType {
	WITHDRAW,
	DEPOSIT
}
