package myapps;

import java.util.Properties;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.json.JSONObject;

public class KafkaJsonProducer {
    public static void main(String[] args) throws Exception{
        Properties props = new Properties();
        props.put("bootstrap.servers", "localhost:9092");
        //props.put("bootstrap.servers", "amqs-kafka-bootstrap-amq-streams.apps.cluster-rfzth.dynamic.opentlc.com:443");
        //props.put("security.protocol","SSL");
        //props.put("ssl.truststore.location","/Users/snowfish/2023_projects/Unimicron/workspaces/um-comm-lab/src/main/resources/truststore.jks");
        //props.put("ssl.truststore.password","1qaz@WSX");
        props.put("key.serializer","org.apache.kafka.common.serialization.StringSerializer");          
        props.put("value.serializer","org.apache.kafka.common.serialization.StringSerializer");

        Producer<String, String> producer = new KafkaProducer<>(props);

        JSONObject result = new JSONObject();
        result.put("result", "test");
        result.put("result1", "test1");
        result.put("result2", "test2");

        JSONObject spcObj = new JSONObject();
        //obj.put("batchId", "111");
        spcObj.put("source", "SPC");
        spcObj.put("result", result);

        JSONObject ncnObj = new JSONObject();
        ncnObj.put("source", "NCN");
        ncnObj.put("result", result);

        JSONObject cpvObj = new JSONObject();
        cpvObj.put("source", "CPV");
        cpvObj.put("result", result);

        JSONObject messData = new JSONObject();
        messData.put("messData", "test");
        messData.put("messData1", "test1");
        messData.put("messData2", "test2");

        JSONObject userInfo = new JSONObject();
        userInfo.put("id", "1234");
        userInfo.put("name", "snowfish");

        JSONObject statusObj = new JSONObject();
        statusObj.put("source", "MES");
        statusObj.put("result", messData);
        statusObj.put("count", 3);

        for (int i = 0; i < 12; i++) {
            String KEY = "2023_12_05_000000-A3911-000000" + String.valueOf(i);
            statusObj.put("batch_id", KEY);
            spcObj.put("batch_id", KEY);
            ncnObj.put("batch_id", KEY);
            cpvObj.put("batch_id", KEY);

            producer.send(new ProducerRecord<String, String>("um-ibdi-comm-status", KEY, statusObj.toString()));

            producer.send(new ProducerRecord<String, String>("um-ibdi-comm-spc-result", KEY, spcObj.toString()));
            producer.send(new ProducerRecord<String, String>("um-ibdi-comm-ncn-result", KEY, ncnObj.toString()));
            producer.send(new ProducerRecord<String, String>("um-ibdi-comm-cpv-result", KEY, cpvObj.toString()));
        }

        // String KEY1 = "2023_12_08_000000-A3911-070128D3";
        // String KEY2 = "2023_12_09_000000-A3911-070128D4";

        // statusObj.put("batch_id", KEY1);
        
        // spcObj.put("batch_id", KEY1);
        // ncnObj.put("batch_id", KEY1);
        // cpvObj.put("batch_id", KEY1);

        // producer.send(new ProducerRecord<String, String>("um-ibdi-comm-status", KEY1, statusObj.toString()));

        // statusObj.put("batch_id", KEY2);
        // producer.send(new ProducerRecord<String, String>("um-ibdi-comm-status", KEY2, statusObj.toString()));

        // producer.send(new ProducerRecord<String, String>("um-ibdi-comm-spc-result", KEY1, spcObj.toString()));
        // producer.send(new ProducerRecord<String, String>("um-ibdi-comm-ncn-result", KEY1, ncnObj.toString()));
        // //producer.send(new ProducerRecord<String, String>("um-ibdi-comm-cpv-result", KEY1, cpvObj.toString()));

        // spcObj.put("batch_id", KEY2);
        // ncnObj.put("batch_id", KEY2);
        // cpvObj.put("batch_id", KEY2);
        // producer.send(new ProducerRecord<String, String>("um-ibdi-comm-spc-result", KEY2, spcObj.toString()));
        // producer.send(new ProducerRecord<String, String>("um-ibdi-comm-ncn-result", KEY2, ncnObj.toString()));
        // //producer.send(new ProducerRecord<String, String>("um-ibdi-comm-cpv-result", KEY2, cpvObj.toString()));

        producer.close();
    }
}
