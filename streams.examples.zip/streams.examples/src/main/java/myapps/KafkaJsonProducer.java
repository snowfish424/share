package myapps;

import java.util.Properties;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.json.JSONObject;

public class KafkaJsonProducer {
    public static void main(String[] args) throws Exception{
        Properties props = new Properties();
        props.put("bootstrap.servers", "localhost:9092");
        props.put("key.serializer","org.apache.kafka.common.serialization.StringSerializer");          
        props.put("value.serializer","org.apache.kafka.common.serialization.StringSerializer");

        Producer<String, String> producer = new KafkaProducer<>(props);

        JSONObject result = new JSONObject();
        result.put("test", "test");
        result.put("test1", "test1");
        result.put("test2", "test2");

        JSONObject spcObj = new JSONObject();
        //obj.put("batchId", "111");
        spcObj.put("source", "SPC");
        spcObj.put("count", "3");
        spcObj.put("result", result);

        JSONObject ncnObj = new JSONObject();
        ncnObj.put("source", "NCN");
        ncnObj.put("count", "3");
        ncnObj.put("result", result);

        JSONObject cpvObj = new JSONObject();
        cpvObj.put("source", "CPV");
        cpvObj.put("count", "3");
        cpvObj.put("result", result);

        JSONObject messData = new JSONObject();
        messData.put("messData", "test");
        messData.put("messData1", "test1");
        messData.put("messData2", "test2");

        JSONObject userInfo = new JSONObject();
        userInfo.put("id", "1234");
        userInfo.put("name", "snowfish");

        JSONObject statusObj = new JSONObject();
        statusObj.put("mesData", messData);
        statusObj.put("userInfo", userInfo);
        statusObj.put("count", 3);


        String KEY1 = "aa";
        String KEY2 = "bb";

        producer.send(new ProducerRecord<String, String>("um-status", KEY1, statusObj.toString()));
        producer.send(new ProducerRecord<String, String>("um-status", KEY2, statusObj.toString()));

        producer.send(new ProducerRecord<String, String>("um-spc", KEY1, spcObj.toString()));
        producer.send(new ProducerRecord<String, String>("um-ncn", KEY1, ncnObj.toString()));
        producer.send(new ProducerRecord<String, String>("um-cpv", KEY1, cpvObj.toString()));

        producer.send(new ProducerRecord<String, String>("um-spc", KEY2, spcObj.toString()));
        producer.send(new ProducerRecord<String, String>("um-ncn", KEY2, ncnObj.toString()));
        producer.send(new ProducerRecord<String, String>("um-cpv", KEY2, cpvObj.toString()));

        producer.close();
    }
}
