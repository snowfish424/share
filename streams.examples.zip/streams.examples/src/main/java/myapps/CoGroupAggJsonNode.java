/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements. See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package myapps;

import org.apache.kafka.common.serialization.Deserializer;
import org.apache.kafka.common.serialization.Serde;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.common.serialization.Serializer;
import org.apache.kafka.connect.json.JsonDeserializer;
import org.apache.kafka.connect.json.JsonSerializer;
import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.StreamsConfig;
import org.apache.kafka.streams.Topology;
import org.apache.kafka.streams.kstream.Aggregator;
import org.apache.kafka.streams.kstream.CogroupedKStream;
import org.apache.kafka.streams.kstream.Consumed;
import org.apache.kafka.streams.kstream.Grouped;
import org.apache.kafka.streams.kstream.Initializer;
import org.apache.kafka.streams.kstream.KGroupedStream;
import org.apache.kafka.streams.kstream.KStream;
import org.apache.kafka.streams.kstream.KTable;
import org.apache.kafka.streams.kstream.Materialized;
import org.apache.kafka.streams.kstream.Produced;
import org.json.JSONObject;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;

import java.util.Properties;
import java.util.concurrent.CountDownLatch;

/**
 * In this example, we implement a simple Pipe program using the high-level Streams DSL
 * that reads from a source topic "streams-plaintext-input", where the values of messages represent lines of text,
 * and writes the messages as-is into a sink topic "streams-pipe-output".
 */
public class CoGroupAggJsonNode {

    public static void main(String[] args) {
        Properties props = new Properties();
        props.put(StreamsConfig.APPLICATION_ID_CONFIG, "co-group-agg");
        props.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
        props.put(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG, Serdes.String().getClass());
        props.put(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG, Serdes.String().getClass());

        final Serializer<JsonNode> jsonNodeSerializer = new JsonSerializer();
        final Deserializer<JsonNode> jsonNodeDeserializer = new JsonDeserializer();
        final Serde<JsonNode> jsonNodeSerde = Serdes.serdeFrom(jsonNodeSerializer, jsonNodeDeserializer);
        
        final StreamsBuilder builder = new StreamsBuilder();

        //JSONObject spcResult = new JSONObject();
        ObjectNode spcResult = JsonNodeFactory.instance.objectNode();
        spcResult.put("type", "spc");
        spcResult.put("result", "spcResult");

        //JSONObject ncnResult = new JSONObject();
        ObjectNode ncnResult = JsonNodeFactory.instance.objectNode();
        ncnResult.put("type", "ncn");
        ncnResult.put("result", "ncnResult");

        //JSONObject cpvResult = new JSONObject();
        ObjectNode cpvResult = JsonNodeFactory.instance.objectNode();
        cpvResult.put("type", "cpv");
        cpvResult.put("result", "cpvResult");

        //JSONObject aggData = new JSONObject();
        //ObjectNode aggData = JsonNodeFactory.instance.objectNode();

        final Aggregator<String, JsonNode, ObjectNode> commAggregator = new Aggregator<String, JsonNode, ObjectNode>() { 
            @Override
            public ObjectNode apply(String aggKey, JsonNode newValue, ObjectNode aggValue) {
                //aggValue.put("batchId", aggKey);
                switch (newValue.get("type").toString()) {
                    case "SPC":
                        aggValue.put("spcResult", spcResult.toPrettyString());
                        break;
                    case "NCN":
                        aggValue.put("ncnResult", ncnResult.toPrettyString());
                        break;
                    case "CPV":
                        aggValue.put("cpvResult", cpvResult.toPrettyString());
                        break;
                    default:
                        break;
                }
                
                //aggValue.put("count", 1);

                return aggValue;
            }
        };

        KStream<String, JsonNode> spcStream = builder.stream("um-spc", Consumed.with(Serdes.String(), jsonNodeSerde));
        KGroupedStream<String, JsonNode> spcGroupedStream = spcStream.groupByKey(Grouped.with(Serdes.String(), jsonNodeSerde));
        
        KStream<String, JsonNode> ncnStream = builder.stream("um-ncn", Consumed.with(Serdes.String(), jsonNodeSerde));
        KGroupedStream<String, JsonNode> ncnGroupedStream = ncnStream.groupByKey(Grouped.with(Serdes.String(), jsonNodeSerde));

        KStream<String, JsonNode> cpvStream = builder.stream("um-cpv", Consumed.with(Serdes.String(), jsonNodeSerde));
        KGroupedStream<String, JsonNode> cpvGroupedStream = cpvStream.groupByKey(Grouped.with(Serdes.String(), jsonNodeSerde));

        CogroupedKStream<String, ObjectNode> cogroupedStream = spcGroupedStream.cogroup(commAggregator)
            .cogroup(ncnGroupedStream, commAggregator)
            .cogroup(cpvGroupedStream, commAggregator);
        
        KTable<String, ObjectNode> coTable = cogroupedStream.aggregate(() -> JsonNodeFactory.instance.objectNode());

        coTable.toStream().mapValues(value -> value.toString()).to("group-agg-output");
        //coTable.toStream().to("group-agg-output", Produced.with(Serdes.String(), jsonNodeSerde));

        final Topology topology = builder.build();
        final KafkaStreams streams = new KafkaStreams(topology, props);
        final CountDownLatch latch = new CountDownLatch(1);

        // attach shutdown handler to catch control-c
        Runtime.getRuntime().addShutdownHook(new Thread("streams-shutdown-hook") {
            @Override
            public void run() {
                streams.close();
                latch.countDown();
            }
        });

        try {
            streams.start();
            latch.await();
        } catch (Throwable e) {
            System.exit(1);
        }
        System.exit(0);
    }
}
