/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements. See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package myapps;

import org.apache.kafka.common.serialization.Serde;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.common.utils.Bytes;
import org.apache.kafka.connect.json.JsonDeserializer;
import org.apache.kafka.connect.json.JsonSerializer;
import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.KeyValue;
import org.apache.kafka.streams.StoreQueryParameters;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.StreamsConfig;
import org.apache.kafka.streams.Topology;
import org.apache.kafka.streams.kstream.Aggregator;
import org.apache.kafka.streams.kstream.CogroupedKStream;
import org.apache.kafka.streams.kstream.Grouped;
import org.apache.kafka.streams.kstream.KGroupedStream;
import org.apache.kafka.streams.kstream.KStream;
import org.apache.kafka.streams.kstream.KTable;
import org.apache.kafka.streams.kstream.Materialized;
import org.apache.kafka.streams.kstream.Produced;
import org.apache.kafka.streams.kstream.ValueJoiner;
import org.apache.kafka.streams.state.KeyValueIterator;
import org.apache.kafka.streams.state.KeyValueStore;
import org.apache.kafka.streams.state.QueryableStoreTypes;
import org.apache.kafka.streams.state.ReadOnlyKeyValueStore;
import org.json.JSONObject;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;

import java.util.Optional;
import java.util.Properties;
import java.util.concurrent.CountDownLatch;

/**
 * In this example, we implement a simple Pipe program using the high-level Streams DSL
 * that reads from a source topic "streams-plaintext-input", where the values of messages represent lines of text,
 * and writes the messages as-is into a sink topic "streams-pipe-output".
 */
public class CoGroupAggJSON {

    public static void main(String[] args) {
        Properties props = new Properties();
        props.put(StreamsConfig.APPLICATION_ID_CONFIG, "co-group-agg");
        props.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
        props.put(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG, Serdes.String().getClass());
        props.put(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG, Serdes.String().getClass());
        
        final Serde<JsonNode> jsonNodeSerde = Serdes.serdeFrom(new JsonSerializer(), new JsonDeserializer());
        final StreamsBuilder builder = new StreamsBuilder();

        JSONObject spcResult = new JSONObject();
        spcResult.put("source", "spc");
        spcResult.put("result", "spcResult");

        JSONObject ncnResult = new JSONObject();
        ncnResult.put("source", "ncn");
        ncnResult.put("result", "ncnResult");

        JSONObject cpvResult = new JSONObject();
        cpvResult.put("source", "cpv");
        cpvResult.put("result", "cpvResult");

        final Aggregator<String, String, String> commAggregator = new Aggregator<String, String, String>() { 
            @Override
            public String apply(String aggKey, String newValue, String aggValue) {
                JSONObject aggJsonObj = new JSONObject();
                int count = 1;
                if (!aggValue.equals("")) {
                    aggJsonObj = new JSONObject(aggValue);
                    count = aggJsonObj.getInt("checkCount") + 1;
                };

                JSONObject newJsonValue = new JSONObject(newValue);
                
                aggJsonObj.put("batchId", aggKey);
                switch (newJsonValue.get("source").toString()) {
                    case "SPC":
                        aggJsonObj.put("spcResult", newJsonValue.get("result"));
                        break;
                    case "NCN":
                        aggJsonObj.put("ncnResult", newJsonValue.get("result"));
                        break;
                    case "CPV":
                        aggJsonObj.put("cpvResult", newJsonValue.get("result"));
                        break;
                    default:
                        break;
                }
                
                // aggJsonObj.remove("mesData");
                // aggJsonObj.remove("userInfo");
                aggJsonObj.put("checkCount", count);

                return aggJsonObj.toString();
            }
        };

        KStream<String, String> statusStream = builder.stream("um-status");
        KTable<String, String> statussTable = statusStream.groupByKey()
            .aggregate(
                () -> "" , 
                (aggKey, newValue, aggValue) -> aggValue +=  newValue, 
                Materialized.as("StatusStore"));
                //Materialized.<String, String, KeyValueStore<Bytes, byte[]> >as("StatusStore"));
            
        KStream<String, String> spcStream = builder.stream("um-spc");
        KGroupedStream<String, String> spcGroupedStream = spcStream.groupByKey();
        
        KStream<String, String> ncnStream = builder.stream("um-ncn");
        KGroupedStream<String, String> ncnGroupedStream = ncnStream.groupByKey();

        KStream<String, String> cpvStream = builder.stream("um-cpv");
        KGroupedStream<String, String> cpvGroupedStream = cpvStream.groupByKey();

        CogroupedKStream<String, String> cogroupedStream = spcGroupedStream.cogroup(commAggregator)
            .cogroup(ncnGroupedStream, commAggregator)
            .cogroup(cpvGroupedStream, commAggregator);
        
        //KTable<String, String> coTable = cogroupedStream.aggregate(() -> new JSONObject());
        KTable<String, String> coTable = cogroupedStream
            .aggregate(
                () -> "", 
                Materialized.as("AggStore"))
            .join(statussTable, 
                new ValueJoiner<String, String, String>() {
                    @Override
                    public String apply(String aggValue, String statusValue) {
                        JSONObject aggJsonObj = new JSONObject(aggValue.toString());
                        JSONObject statusJsonObj = new JSONObject(statusValue.toString());
                        if (aggJsonObj.get("checkCount").equals(statusJsonObj.get("count"))) {
                            aggJsonObj.put("aggMesData", statusJsonObj.get("mesData"));
                            aggJsonObj.put("aggUserInfo", statusJsonObj.get("userInfo"));

                            return aggJsonObj.toString();
                        }

                        return null;
                    }
                })
            .toStream().groupByKey().aggregate(
                () -> "", 
                (aggKey, newValue, aggValue) -> newValue);
            //.join(statussTable, (leftValue, rightValue) -> "left=" + leftValue + ", right=" + rightValue);

        //KTable<String, String> coTable = cogroupedStream.aggregate(() -> "", Materialized.with(Serdes.String(), Serdes.String()));
        coTable.toStream().to("group-agg-output");

        final Topology topology = builder.build();
        final KafkaStreams streams = new KafkaStreams(topology, props);
        final CountDownLatch latch = new CountDownLatch(1);

        // attach shutdown handler to catch control-c
        Runtime.getRuntime().addShutdownHook(new Thread("streams-shutdown-hook") {
            @Override
            public void run() {
                streams.close();
                latch.countDown();
            }
        });

        try {
            streams.cleanUp();
            streams.start();

            // // Get the key-value store StatusStore
            // ReadOnlyKeyValueStore<String, String> statusStore = 
            //     streams.store(StoreQueryParameters.fromNameAndType("StatusStore",QueryableStoreTypes.keyValueStore()));
            
            // //System.out.println("get statusStore " + statusStore.get("111"));

            // // Get the key-value store StatusStore
            // ReadOnlyKeyValueStore<String, String> aggStore = 
            //     streams.store(StoreQueryParameters.fromNameAndType("AggStore",QueryableStoreTypes.keyValueStore()));
            
            // KeyValueIterator<String, String> range = aggStore.all();
            // while (range.hasNext()) {
            //     KeyValue<String, String> next = range.next();
            //     System.out.println("get aggStore " + next.key + ": " + next.value);
            //     JSONObject aggJsonObj = new JSONObject(next.value.toString());
            //     JSONObject statusJsonObj = new JSONObject(statusStore.get(next.key).toString());
            //     System.out.println("get statusStore count: " + statusJsonObj.get("count"));
            //     System.out.println("get aggJsonObj count: " + aggJsonObj.get("checkCount"));
            //     if (statusJsonObj.get("count").equals(aggJsonObj.get("checkCount"))) 
            //         coTable.toStream().to("group-agg-output");
            //     else 
            //         System.out.println("============== no check ===============");
            // }

            //coTable.toStream().to("group-agg-output");
            latch.await();
        } catch (Throwable e) {
            e.printStackTrace();
            System.exit(1);
        }
        System.exit(0);
    }
}
