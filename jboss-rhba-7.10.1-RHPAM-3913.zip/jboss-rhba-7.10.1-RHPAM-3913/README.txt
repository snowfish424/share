PATCH NAME: 
  RHPAM-3913

PRODUCT NAME: 
  Red Hat Process Automation Manager

VERSION: 
  7.10.1.GA

DESCRIPTION: One-off patch to fix the following issue:

* https://issues.redhat.com/browse/RHPAM-3782
    Oracle - Long running query at kie-server startup
  
MANUAL INSTALL INSTRUCTIONS FOR ALL PLATFORMS:

1. Backup and remove the following jar:

     kie-soup-dataset-sql-7.48.0.Final-redhat-00006.jar

      
   from the following locations:

      $SERVER_DEPLOYMENT_DIR/kie-server.war/WEB-INF/lib/
      $SERVER_DEPLOYMENT_DIR/business-central.war/WEB-INF/lib/

2. Unzip the file jboss-rhba-7.10.1-RHPAM-3913.zip and copy:

	RHPAM-3913/kie-soup-dataset-sql-7.48.0.Final-redhat-00006-RHPAM-3913.jar
	      
   to:

      $SERVER_DEPLOYMENT_DIR/kie-server.war/WEB-INF/lib
      $SERVER_DEPLOYMENT_DIR/business-central.war/WEB-INF/lib/

MANUAL INSTALL INSTRUCTIONS FOR MAVEN BASED PROJECTS:

    1. Extract the attached zip (jboss-rhba-7.10.1-RHPAM-3913.zip) and change into the RHPAM-3913 directory

    2. Run the following commands to install the patch binaries to the local maven repository:
    
mvn install:install-file -Dfile=kie-soup-dataset-sql-7.48.0.Final-redhat-00006-RHPAM-3913.jar -Dsources=kie-soup-dataset-sql-7.48.0.Final-redhat-00006-RHPAM-3913-sources.jar -DpomFile=kie-soup-dataset-sql-7.48.0.Final-redhat-00006-RHPAM-3913.pom -Dpackaging=jar

       

    3. Override the original version of modified jars explicitly declaring them in <dependencyManagement> of your project pom.xml:

             <dependency>
                <groupId>org.kie.soup</groupId>
                <artifactId>kie-soup-dataset-sql</artifactId>
                <version>7.48.0.Final-redhat-00006-RHPAM-3913</version>
             </dependency>
             


CREATOR:
        Abhijit Humbe
DATE:
        23-Sept-2021
