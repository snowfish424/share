import json
import logging
from kafka import KafkaConsumer

logging.basicConfig(level=logging.INFO)

ORDER_KAFKA_TOPIC = ""
BOOT_STRAP_SERVER = ""

# consumer
consumer = KafkaConsumer(
    ORDER_KAFKA_TOPIC,
    bootstrap_servers=BOOT_STRAP_SERVER,
    security_protocol='SSL',
    ssl_cafile='ca.crt',

)

if __name__ == '__main__':
    logging.info("Started consuming messages...")
    while True:
        for message in consumer:
            consumed_message = json.loads(message.value.decode("utf-8"))
            logging.info(f"Successful receive messages ... {consumed_message}")
         






