import json
import time
import logging
from kafka import KafkaProducer

logging.basicConfig(level=logging.INFO)

# create kafka topic
ORDER_KAFKA_TOPIC = ""
ORDER_LIMIT = 100
KAFKA_SERVER = ""


producer = KafkaProducer(bootstrap_servers=KAFKA_SERVER,
                         security_protocol='SSL',
                         ssl_cafile='ca.crt')


def create_orders():
    orders ={'order_id': '117c4026-087a-4c7b-982c-033476ed9775', 'username': 'olivia68', 'first_name': 'Donna', 'last_name': 'Martinez', 'email': 'sschmidt@example.org', 'quantity': 155, 'price': 54.88, 'date_created': '2023-11-08 10:00:06.474537'}
    return orders


if __name__ == '__main__':
    logging.info("Generating orders...")
    for order in range(1, ORDER_LIMIT+1):
        data = create_orders()
        # send orders to kafka topic
        producer.send(ORDER_KAFKA_TOPIC, json.dumps(data).encode("utf-8"))
        logging.info(f"Done creating order ...{order} - {data}")
        time.sleep(1)
